JIRA_URL = "https://simijain650.atlassian.net/rest/api/3/issue"
USER_NAME = "simijain650@gmail.com"
API_TOKEN = "ATATT3xFfGF09fI5h3MDIltR1zSe0gQ97zm-r3ilJRAkdYaEKvgyZN96Tsv_mmq9f_tpaG17-gm5g7F4e5745k0xTYIW70KtDgLnOqBT1MQT7zQ_nXet29ShW8M-_BmPJ0BYuZK4PHGJpeh7Xu1IbqEznbr5jNofUBstKBIOGIiVRdFmEGBFQ30=D85C9F6D"
PROJECT_KEY = "TEST"
